const $ = id => document.getElementById(id);
const state = { user: null, authMode: "login", mode: "chat", chats: [], currentId: null, busy: false };

function toast(message) {
  const el = $("toast");
  if (!el) return;
  el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove("show"), 2600);
}
async function api(url, options = {}) {
  const headers = { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) };
  const response = await fetch(url, { credentials: "same-origin", ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Permintaan gagal.");
  return data;
}
function showAuth() { $("authView").classList.remove("hidden"); $("appView").classList.add("hidden"); }
function showApp() {
  $("authView").classList.add("hidden"); $("appView").classList.remove("hidden");
  const name = state.user.username;
  $("accountName").textContent = name; $("welcomeName").textContent = name;
  $("avatar").textContent = name[0].toUpperCase(); $("miniAvatar").textContent = name[0].toUpperCase();
  loadChats(); renderHistory(); newChat();
}
function setAuthMode(mode) {
  state.authMode = mode;
  const register = mode === "register";
  $("authTitle").innerHTML = register ? 'Create your <span>account.</span>' : 'Welcome <span>back.</span>';
  $("authSubtitle").textContent = register ? "Daftar untuk mulai menggunakan hamXai." : "Masuk dan lanjutkan ide hebatmu.";
  $("usernameWrap").classList.toggle("hidden", !register);
  $("emailWrap").classList.toggle("hidden", !register);
  $("identityWrap").classList.toggle("hidden", register);
  $("authSubmit").innerHTML = register ? 'Buat akun <span>↗</span>' : 'Masuk ke hamXai <span>↗</span>';
  $("switchText").textContent = register ? "Sudah punya akun?" : "Belum punya akun?";
  $("switchAuth").textContent = register ? "Masuk" : "Daftar";
  $("authError").classList.add("hidden");
}
$("switchAuth").addEventListener("click", () => setAuthMode(state.authMode === "login" ? "register" : "login"));
$("authForm").addEventListener("submit", async event => {
  event.preventDefault();
  const button = $("authSubmit"); button.disabled = true;
  try {
    const register = state.authMode === "register";
    const body = register
      ? { username: $("username").value, email: $("email").value, password: $("password").value }
      : { identity: $("identity").value, password: $("password").value };
    const result = await api(register ? "/api/register" : "/api/login", { method: "POST", body: JSON.stringify(body) });
    state.user = result.user; showApp();
  } catch (err) {
    $("authError").textContent = err.message; $("authError").classList.remove("hidden");
  } finally { button.disabled = false; }
});
$("logoutBtn").addEventListener("click", async () => {
  try { await api("/api/logout", { method: "POST", body: "{}" }); } catch {}
  state.user = null; state.chats = []; showAuth();
});

function storageKey() { return `hamxai_purple_${state.user.id}`; }
function loadChats() {
  try { state.chats = JSON.parse(localStorage.getItem(storageKey()) || "[]"); }
  catch { state.chats = []; }
  state.chats = state.chats.slice(0, 40);
}
function saveChats() { localStorage.setItem(storageKey(), JSON.stringify(state.chats.slice(0, 40))); renderHistory(); }
function renderHistory() {
  const list = $("historyList"); list.innerHTML = "";
  if (!state.chats.length) { list.innerHTML = '<p class="empty-history">Percakapanmu akan muncul di sini.</p>'; return; }
  state.chats.forEach(chat => {
    const btn = document.createElement("button");
    btn.className = "history-item" + (chat.id === state.currentId ? " selected" : "");
    btn.textContent = chat.title || "New chat";
    btn.addEventListener("click", () => openChat(chat.id));
    list.appendChild(btn);
  });
}
function currentChat() { return state.chats.find(chat => chat.id === state.currentId); }
function newChat() {
  const chat = { id: crypto.randomUUID(), title: "New chat", mode: state.mode, messages: [] };
  state.chats.unshift(chat); state.currentId = chat.id; saveChats();
  $("messages").innerHTML = ""; $("welcome").classList.remove("hidden"); $("chatPanel").classList.add("hidden");
  $("sidebar").classList.remove("open");
}
function openChat(id) {
  const chat = state.chats.find(item => item.id === id); if (!chat) return;
  state.currentId = id; setMode(chat.mode || "chat", false);
  $("welcome").classList.add("hidden"); $("chatPanel").classList.remove("hidden");
  $("messages").innerHTML = ""; chat.messages.forEach(addMessage);
  renderHistory(); $("sidebar").classList.remove("open");
}
function setMode(mode, reset = true) {
  state.mode = mode;
  document.querySelectorAll(".nav-link").forEach(el => el.classList.toggle("active", el.dataset.mode === mode));
  $("modeTitle").textContent = mode === "code" ? "Coding Assistant" : "AI Chat";
  $("messageInput").placeholder = mode === "code" ? "Tanyakan sesuatu tentang coding..." : "Message hamXai...";
  if (reset) newChat();
}
$("newChat").addEventListener("click", () => { setMode("chat"); });
document.querySelectorAll(".nav-link").forEach(el => el.addEventListener("click", () => {
  setMode(el.dataset.mode); $("sidebar").classList.remove("open");
}));
$("clearHistory").addEventListener("click", () => {
  if (!confirm("Hapus seluruh riwayat chat di browser ini?")) return;
  state.chats = []; state.currentId = null; saveChats(); newChat();
});
$("openSidebar").addEventListener("click", () => $("sidebar").classList.add("open"));
$("closeSidebar").addEventListener("click", () => $("sidebar").classList.remove("open"));
document.querySelectorAll(".quick-card").forEach(btn => btn.addEventListener("click", () => {
  setMode("chat"); $("messageInput").value = btn.dataset.prompt; sendMessage();
}));
function addMessage(message) {
  const row = document.createElement("div"); row.className = `message ${message.role}`;
  const icon = document.createElement("div"); icon.className = "message-icon";
  icon.textContent = message.role === "user" ? state.user.username[0].toUpperCase() : "h";
  const bubble = document.createElement("div"); bubble.className = "bubble";
  bubble.textContent = message.content; // Render model output as text, never as HTML.
  row.append(icon, bubble); $("messages").appendChild(row);
}
async function sendMessage() {
  const text = $("messageInput").value.trim();
  if (!text || state.busy) return;
  if (!currentChat()) newChat();
  const chat = currentChat();
  const userMessage = { role: "user", content: text };
  chat.messages.push(userMessage);
  if (chat.messages.length === 1) chat.title = text.slice(0, 36);
  addMessage(userMessage);
  $("messageInput").value = ""; resizeInput();
  $("welcome").classList.add("hidden"); $("chatPanel").classList.remove("hidden");
  state.busy = true; $("sendBtn").disabled = true; $("thinking").classList.remove("hidden");
  saveChats();
  try {
    const result = await api("/api/chat", {
      method: "POST",
      body: JSON.stringify({ mode: state.mode, messages: chat.messages.slice(-16) })
    });
    const answer = { role: "assistant", content: result.reply };
    chat.messages.push(answer); addMessage(answer);
  } catch (err) {
    const answer = { role: "assistant", content: `Terjadi kendala: ${err.message}` };
    chat.messages.push(answer); addMessage(answer);
  } finally {
    state.busy = false; $("sendBtn").disabled = false; $("thinking").classList.add("hidden");
    saveChats(); $("messageInput").focus();
  }
}
$("chatForm").addEventListener("submit", e => { e.preventDefault(); sendMessage(); });
$("messageInput").addEventListener("keydown", e => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});
$("messageInput").addEventListener("input", resizeInput);
function resizeInput() {
  const el = $("messageInput"); el.style.height = "auto"; el.style.height = Math.min(el.scrollHeight, 150) + "px";
}
(async function init() {
  try {
    const result = await api("/api/me");
    if (result.user) { state.user = result.user; showApp(); } else showAuth();
  } catch { showAuth(); }
})();
