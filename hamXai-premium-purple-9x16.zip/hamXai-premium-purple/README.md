# hamXai — Premium Purple

Website AI responsif dengan tema premium purple.

## Fitur
- AI Chat menggunakan OpenAI Responses API
- Coding Assistant
- Chat History di browser (localStorage)
- Login dan Register dengan password hashing bcrypt
- Session login disimpan di SQLite
- Tampilan responsif untuk HP, tablet, dan desktop

## Persyaratan
- Node.js 20 atau lebih baru
- OpenAI API Key dengan akses dan billing aktif
- Hosting Node.js dengan disk persisten untuk database SQLite

## Menjalankan lokal
1. Ekstrak ZIP.
2. Buka terminal di folder proyek.
3. Jalankan `npm install`.
4. Salin `.env.example` menjadi `.env`.
5. Isi `OPENAI_API_KEY` dan `SESSION_SECRET` pada `.env`.
6. Jalankan `npm start`.
7. Buka `http://localhost:3000`.

## Konfigurasi .env
```env
OPENAI_API_KEY=API_KEY_KAMU
SESSION_SECRET=string_acak_panjang_minimal_32_karakter
PORT=3000
NODE_ENV=development
OPENAI_MODEL=gpt-5.5
```
`OPENAI_MODEL` dapat diganti ke model yang tersedia di project API OpenAI milikmu.

## Hosting
Deploy sebagai aplikasi Node.js (bukan static-only hosting). Atur environment variables:
- `OPENAI_API_KEY`
- `SESSION_SECRET`
- `NODE_ENV=production`
- `OPENAI_MODEL` (opsional)
- `PORT` (biasanya diatur otomatis oleh platform)

Pastikan folder `data/` berada pada persistent disk/volume. Aplikasi menyimpan akun dan sesi di SQLite. Jangan memakai serverless/hosting tanpa persistent storage untuk konfigurasi ini.

## Keamanan dan batasan
- API Key hanya berada di server, jangan masukkan ke `public/` atau frontend.
- `.env` sudah diabaikan Git melalui `.gitignore`.
- Riwayat chat disimpan di localStorage browser, tidak tersinkron antarperangkat.
- Ini starter project; sebelum dibuka ke publik, tambahkan verifikasi email, reset password, CSRF protection sesuai deployment, backup, kebijakan privasi, dan kontrol penyalahgunaan yang lebih kuat.
