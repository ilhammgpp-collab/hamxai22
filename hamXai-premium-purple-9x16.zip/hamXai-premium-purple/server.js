import "dotenv/config";
import express from "express";
import session from "express-session";
import SQLiteStoreFactory from "connect-sqlite3";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const production = process.env.NODE_ENV === "production";
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("Isi SESSION_SECRET dengan string acak minimal 32 karakter.");
}

const db = new Database(path.join(dataDir, "hamxai.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )
`);

const SQLiteStore = SQLiteStoreFactory(session);
app.set("trust proxy", 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "https://fonts.googleapis.com"],
      fontSrc: ["'self'", "https://fonts.gstatic.com"],
      imgSrc: ["'self'", "data:"],
      connectSrc: ["'self'"],
      objectSrc: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: "1mb" }));
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: production,
    sameSite: "lax",
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));

const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false });
const chatLimiter = rateLimit({ windowMs: 60 * 1000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false });
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

const clean = (v, max = 8000) => String(v ?? "").trim().slice(0, max);
const safeUser = u => ({ id: u.id, username: u.username, email: u.email });
function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Silakan login terlebih dahulu." });
  next();
}
function requireAI(_req, res, next) {
  if (!openai) return res.status(503).json({ error: "OpenAI API belum dikonfigurasi. Isi OPENAI_API_KEY di environment hosting." });
  next();
}

app.post("/api/register", authLimiter, async (req, res) => {
  try {
    const username = clean(req.body.username, 24);
    const email = clean(req.body.email, 120).toLowerCase();
    const password = String(req.body.password || "");
    if (!/^[a-zA-Z0-9_]{3,24}$/.test(username)) {
      return res.status(400).json({ error: "Username harus 3–24 karakter: huruf, angka, atau underscore." });
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Format email tidak valid." });
    if (password.length < 8 || password.length > 72) return res.status(400).json({ error: "Password harus 8–72 karakter." });
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (username,email,password_hash) VALUES (?,?,?)").run(username, email, hash);
    const user = db.prepare("SELECT id,username,email FROM users WHERE id=?").get(result.lastInsertRowid);
    req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: "Gagal membuat sesi." });
      req.session.user = user;
      res.json({ user });
    });
  } catch (err) {
    if (String(err).includes("UNIQUE")) return res.status(409).json({ error: "Username atau email sudah digunakan." });
    console.error(err);
    res.status(500).json({ error: "Pendaftaran gagal." });
  }
});

app.post("/api/login", authLimiter, async (req, res) => {
  try {
    const identity = clean(req.body.identity, 120).toLowerCase();
    const password = String(req.body.password || "");
    const user = db.prepare("SELECT * FROM users WHERE lower(email)=? OR lower(username)=?").get(identity, identity);
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Email/username atau password salah." });
    }
    req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: "Gagal membuat sesi." });
      req.session.user = safeUser(user);
      res.json({ user: req.session.user });
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Login gagal." });
  }
});

app.post("/api/logout", requireAuth, (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.post("/api/chat", requireAuth, requireAI, chatLimiter, async (req, res) => {
  try {
    const mode = req.body.mode === "code" ? "code" : "chat";
    const messages = Array.isArray(req.body.messages) ? req.body.messages.slice(-16) : [];
    const input = messages
      .filter(m => ["user", "assistant"].includes(m.role))
      .map(m => ({ role: m.role, content: clean(m.content, 8000) }))
      .filter(m => m.content);

    if (!input.length || input[input.length - 1].role !== "user") {
      return res.status(400).json({ error: "Pesan belum tersedia." });
    }

    const instructions = mode === "code"
      ? "You are hamXai Coding Assistant, an expert programming helper. Explain code clearly, debug errors, and provide complete runnable examples when useful. Reply in the user's language."
      : "You are hamXai, a helpful and friendly AI assistant. Reply in the user's language. Be clear, practical, and honest about uncertainty.";

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions,
      input
    });
    res.json({ reply: response.output_text || "Belum ada teks balasan dari model." });
  } catch (err) {
    console.error("OpenAI error:", err);
    res.status(500).json({ error: "AI gagal membalas. Periksa API Key, kuota, dan nama model." });
  }
});

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: "Terjadi kesalahan pada server." });
});

app.listen(PORT, () => console.log(`hamXai aktif di http://localhost:${PORT}`));
